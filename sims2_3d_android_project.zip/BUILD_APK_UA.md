# The Sims 2: 3D Mobile Edition (Android Studio & APK Project)

Цей архів містить повний Android-проєкт із вбудованим 3D WebGL (Three.js) рушієм гри **The Sims 2: 3D Mobile Edition**.

## Як отримати або встановити гру на Android:

### Варіант 1: Миттєвий запуск на телефоні без компіляції
Відкрийте файл `sims2_3d_mobile.html` (або `app/src/main/assets/index.html`) у браузері Chrome на Android та натисніть **«Додати на головний екран»** — гра запуститься в повноекранному режимі як окремий мобільний 3D-додаток зі збереженням прогресу.

### Варіант 2: Збірка `.apk` в Android Studio (на ПК)
1. Розпакуйте цей архів `sims2_3d_android_project.zip`.
2. Відкрийте папку у **Android Studio** (File -> Open).
3. У верхньому меню виберіть **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
4. Готовий файл з'явиться у `app/build/outputs/apk/debug/app-debug.apk`.

### Варіант 3: Хмарна автозбірка `.apk` без встановлення Android Studio (через GitHub Actions)
1. Завантажте вміст цього архіву у новий репозиторій на GitHub.
2. Перейдіть на вкладку **Actions** — вбудований сценарій `.github/workflows/build-apk.yml` автоматично збере готовий інсталятор **`Sims2-3D-Android-APK` (`app-debug.apk`)**, який можна завантажити прямо на телефон.
